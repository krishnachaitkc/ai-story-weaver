export enum StoryGenre {
  FANTASY = "Fantasy",
  SCI_FI = "Science Fiction",
  MYSTERY = "Mystery",
  COMEDY = "Comedy",
  HORROR = "Horror",
  ADVENTURE = "Adventure",
}
